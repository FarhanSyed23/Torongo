<?php

/* activate.twig */
class __TwigTemplate_299bfb4dcb2a20718159c9d0decbedaba8cddf8cf732b7b1a291f7fb17a0d782 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<iframe id=\"timely-iframe\" src=\"https://dashboard.time.ly/wordpress\" frameborder=\"0\"></iframe>

<script>
   (function () {
       var eventMethod = window.addEventListener ? \"addEventListener\" : \"attachEvent\";
       var eventer = window[eventMethod];
       var messageEvent = eventMethod == \"attachEvent\" ? \"onmessage\" : \"message\";

       // Listen to message from child window
       eventer(messageEvent, function (e) {
           try {
               var response = JSON.parse(decodeURI(e.data));
               if (!response || !response.timely_activate || !response.email || !response.auth_token) {
                   return;
               }
           } catch (e) {
               return;
           }
           var form = document.createElement('form');
           form.method = 'post';
           form.action = window.location.href;

           var actionField = document.createElement('input');
           actionField.type = 'hidden';
           actionField.name = 'ai1ec_save_login';
           actionField.value = '1';
           form.appendChild(actionField);

           var emailField = document.createElement('input');
           emailField.type = 'hidden';
           emailField.name = 'ai1ec_email';
           emailField.value = response.email;
           form.appendChild(emailField);

           var authtokenField = document.createElement('input');
           authtokenField.type = 'hidden';
           authtokenField.name = 'ai1ec_auth_token';
           authtokenField.value = response.auth_token;
           form.appendChild(authtokenField);

           document.body.appendChild(form);
           form.submit();
       }, false);
   })();
</script>

";
    }

    public function getTemplateName()
    {
        return "activate.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
