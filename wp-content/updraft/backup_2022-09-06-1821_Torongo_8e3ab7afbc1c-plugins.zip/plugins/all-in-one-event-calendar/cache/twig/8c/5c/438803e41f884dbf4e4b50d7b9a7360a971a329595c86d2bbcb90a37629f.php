<?php

/* add-ons-list/page.twig */
class __TwigTemplate_8c5c438803e41f884dbf4e4b50d7b9a7360a971a329595c86d2bbcb90a37629f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"wrap\" id=\"ai1ec-add-ons\">
\t<h2>";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["labels"]) ? $context["labels"] : null), "title"), "html", null, true);
        echo "
\t</h2>
\t<p>";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["labels"]) ? $context["labels"] : null), "paragraph_content"), "html", null, true);
        echo "</p>";
        // line 6
        if ((isset($context["is_error"]) ? $context["is_error"] : null)) {
            // line 7
            echo "\t\t<div class=\"error\"><p>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["labels"]) ? $context["labels"] : null), "error"), "html", null, true);
            echo "</p></div>";
        } else {
            // line 9
            echo "\t\t<div class=\"row\" style=\"max-width: 450px; text-align: center; margin-top: 40px;\">
\t\t\t<div class=\"col-sm-6 timely-activate-ev\">
\t\t\t\t<div class=\"timely-activate-ev-title\"
\t\t\t\t\tstyle=\"font-weight: bold; font-size: 18px; margin-bottom: 22px;\">
\t\t\t\t\tExtended Views
\t\t\t\t</div>
\t\t\t\t<div class=\"timely-activate-ev-desc\">
\t\t\t\t\tAdd beautiful views to your calendar with this great add-on.<br />
\t\t\t\t\tDownload the add-on, install and activate it, and you’re set.
\t\t\t\t</div>
\t\t\t\t<div class=\"timely-activate-ev-img\"></div>
\t\t\t\t<a href=\"https://dashboard.time.ly/checkout/extended_views\"
\t\t\t\t   target=\"_blank\"
\t\t\t\t   class=\"btn btn-success timely-activate-ev-button\">
\t\t\t\t\tGET IT NOW
\t\t\t\t</a>
\t\t\t\t<br />
\t\t\t\t<a href=\"https://time.ly/wordpress-extended-visual-views-add-on/\"
\t\t\t\t   target=\"_blank\"
\t\t\t\t   class=\"timely-activate-learn\">
\t\t\t\t\tLearn more
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>";
        }
        // line 34
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "add-ons-list/page.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 34,  37 => 9,  32 => 7,  30 => 6,  27 => 5,  22 => 3,  19 => 1,);
    }
}
