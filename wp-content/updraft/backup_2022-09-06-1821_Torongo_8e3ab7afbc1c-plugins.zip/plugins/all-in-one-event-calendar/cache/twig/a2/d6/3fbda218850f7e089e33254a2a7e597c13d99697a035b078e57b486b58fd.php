<?php

/* notification/admin.twig */
class __TwigTemplate_a2d63fbda218850f7e089e33254a2a7e597c13d99697a035b078e57b486b58fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"message";
        echo twig_escape_filter($this->env, (isset($context["class"]) ? $context["class"] : null), "html", null, true);
        echo " ai1ec-message\">";
        // line 2
        if ((!array_key_exists("label", $context))) {
            // line 3
            $context["label"] = (isset($context["text_label"]) ? $context["text_label"] : null);
        }
        // line 5
        echo "\t<p><strong>";
        echo twig_escape_filter($this->env, (isset($context["label"]) ? $context["label"] : null), "html", null, true);
        echo ":</strong></p>";
        // line 6
        echo (isset($context["message"]) ? $context["message"] : null);
        // line 8
        if ((isset($context["persistent"]) ? $context["persistent"] : null)) {
            // line 9
            echo "\t\t<button class=\"button button-primary ai1ec-dismissable\"
\t\t\tdata-key=\"";
            // line 10
            echo twig_escape_filter($this->env, (isset($context["msg_key"]) ? $context["msg_key"] : null), "html", null, true);
            echo "\">";
            // line 11
            echo twig_escape_filter($this->env, (isset($context["text_dismiss_button"]) ? $context["text_dismiss_button"] : null), "html", null, true);
            echo "
\t\t</button>";
        }
        // line 14
        echo "\t<p></p>
</div>
";
    }

    public function getTemplateName()
    {
        return "notification/admin.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 14,  42 => 11,  39 => 10,  34 => 8,  25 => 3,  23 => 2,  68 => 28,  56 => 17,  51 => 14,  48 => 13,  46 => 12,  40 => 8,  36 => 9,  32 => 6,  28 => 5,  24 => 4,  19 => 1,);
    }
}
