<?php
/**
 * Exceptions occuring during cron setup
 *
 * @author     Time.ly Network Inc.
 * @since      2.0
 *
 * @package    AI1EC
 * @subpackage AI1EC.Exception
 */
class Ai1ec_Scheduling_Exception extends Ai1ec_Exception {


}