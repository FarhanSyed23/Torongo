<?php ?>
<div id="ai1ec_event_inline_alert" class="timely ai1ec-alert ai1ec-alert-danger ai1ec-hidden"></div>