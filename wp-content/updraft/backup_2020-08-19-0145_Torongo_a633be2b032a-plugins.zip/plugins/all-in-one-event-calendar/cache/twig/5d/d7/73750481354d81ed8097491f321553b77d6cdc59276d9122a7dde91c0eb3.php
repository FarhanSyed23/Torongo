<?php

/* widget.twig */
class __TwigTemplate_5dd773750481354d81ed8097491f321553b77d6cdc59276d9122a7dde91c0eb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo (isset($context["before_widget"]) ? $context["before_widget"] : null);
        // line 3
        if ((!twig_test_empty((isset($context["title"]) ? $context["title"] : null)))) {
            // line 4
            echo (((isset($context["before_title"]) ? $context["before_title"] : null) . (isset($context["title"]) ? $context["title"] : null)) . (isset($context["after_title"]) ? $context["after_title"] : null));
        }
        // line 7
        echo (isset($context["widget_html"]) ? $context["widget_html"] : null);
        // line 9
        echo (isset($context["after_widget"]) ? $context["after_widget"] : null);
    }

    public function getTemplateName()
    {
        return "widget.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 7,  193 => 86,  185 => 81,  180 => 78,  173 => 72,  169 => 70,  163 => 69,  155 => 64,  151 => 62,  142 => 60,  140 => 59,  134 => 55,  130 => 53,  124 => 52,  116 => 47,  112 => 45,  106 => 44,  98 => 39,  94 => 37,  88 => 36,  80 => 31,  76 => 29,  70 => 28,  61 => 24,  59 => 23,  55 => 20,  51 => 17,  48 => 15,  34 => 6,  27 => 5,  25 => 4,  23 => 4,  21 => 3,  263 => 95,  260 => 93,  257 => 84,  255 => 83,  249 => 78,  246 => 77,  242 => 75,  240 => 74,  238 => 73,  236 => 72,  233 => 69,  218 => 66,  191 => 62,  189 => 59,  186 => 56,  182 => 79,  179 => 53,  177 => 52,  175 => 51,  172 => 49,  167 => 46,  165 => 45,  160 => 42,  158 => 41,  156 => 40,  152 => 38,  145 => 61,  143 => 35,  139 => 34,  136 => 33,  119 => 32,  102 => 31,  97 => 29,  92 => 27,  90 => 26,  87 => 25,  83 => 24,  79 => 23,  75 => 22,  71 => 21,  65 => 20,  63 => 25,  46 => 14,  43 => 12,  41 => 11,  39 => 14,  37 => 13,  32 => 10,  30 => 9,  28 => 9,  22 => 3,  19 => 1,);
    }
}
